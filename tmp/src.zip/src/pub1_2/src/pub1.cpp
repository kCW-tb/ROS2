#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/vector3.hpp" // Vector3 메시지 헤더 추가
#include <memory>
#include <chrono>

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);

    auto node = std::make_shared<rclcpp::Node>("node_pub1");
    auto qos_profile = rclcpp::QoS(rclcpp::KeepLast(10));
    auto mypub = node->create_publisher<geometry_msgs::msg::Vector3>("topic_pub1", qos_profile);

    geometry_msgs::msg::Vector3 message;
    
    std::cout << "input data" << std::endl;
    std::cin >> message.x >> message.y >> message.z;
    
    message.x = 0.5; // x 초기화
    message.y = 1.5; // y 초기화
    message.z = 2.5; // z 초기화

    rclcpp::WallRate loop_rate(1.0); // 반복 주파수를 저장하는 객체 (단위 Hz)
    
    while (rclcpp::ok())
    {
        // x, y, z 값을 출력
        RCLCPP_INFO(node->get_logger(), "Publish: x=%f, y=%f, z=%f", message.x, message.y, message.z);
        
        mypub->publish(message);

        std::cout << "input data" << endl;
        std::cin >> message.x >> message.y >> message.z;

        loop_rate.sleep(); // 반복 주파수에서 남은 시간만큼 sleep
    }
    
    rclcpp::shutdown();
    return 0;
}
